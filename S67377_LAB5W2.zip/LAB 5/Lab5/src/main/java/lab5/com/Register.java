package lab5.com;
public class Register {   
    private String ic;
    private String name;
    private int pax;
    private int trainingType;
    private double stud;

    public Register(String ic, String name, int pax, int trainingType, int stud) {
        this.ic = ic;
        this.name = name;
        this.pax = pax;
        this.trainingType = trainingType;
        this.stud = stud;
    }  
    public Register(){      
    }
    public String getIc() {
        return ic;
    }
    public String getName() {
        return name;
    }
    public int getPax() {
        return pax;
    }
    public int getTrainingType() {
        return trainingType;
    }
    public double getStud() {
        return stud;
    }
    public void setIc(String ic) {
        this.ic = ic;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPax(int pax) {
        this.pax = pax;
    }
    public void setTrainingType(int trainingType) {
        this.trainingType = trainingType;
    }
    public void setStud(double stud) {
        this.stud = stud;
    }  
}
