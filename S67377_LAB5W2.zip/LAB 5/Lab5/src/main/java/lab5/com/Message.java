package lab5.com;

public class Message { 
    private String msg;
    
    public Message(){
        
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    
    
}
