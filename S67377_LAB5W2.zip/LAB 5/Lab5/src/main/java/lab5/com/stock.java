/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab5.com;

/**
 *
 * @author A D M I N
 */
public class stock {
    
    private int shares;
    private double pricePerShare;
    private double percentCommission;

    public stock(int shares, double pricePerShare, double percentCommission) {
        this.shares = shares;
        this.pricePerShare = pricePerShare;
        this.percentCommission = percentCommission;
    }
    
    public int getShares() {
        return shares;
    }

    public double getPricePerShare() {
        return pricePerShare;
    }

    public double getPercentCommission() {
        return percentCommission;
    }

    public void setShares(int shares) {
        this.shares = shares;
    }

    public void setPricePerShare(double pricePerShare) {
        this.pricePerShare = pricePerShare;
    }

    public void setPercentCommission(double percentCommission) {
        this.percentCommission = percentCommission;
    }
    
    public double calculateAmtStockAlone(){
        return shares*pricePerShare;
    }
    
    public double calculateAmtCommission(){
        return (calculateAmtStockAlone()*percentCommission);
    }
    
    public double calculateTotal(){
        return (calculateAmtCommission()+calculateAmtStockAlone());
    }
    
}
